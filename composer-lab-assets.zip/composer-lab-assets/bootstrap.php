<?php

define('DB_HOST', 'localhost');
define('DB_PORT', 3306);
define('DB_DATABASE', '');
define('DB_CHARSET', 'utf8');
define('DB_USERNAME', '');
define('DB_PASSWORD', '');